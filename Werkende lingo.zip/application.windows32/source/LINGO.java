import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.sound.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class LINGO extends PApplet {

final int START = 1;
final int SPEL = 2;
final int EIND = 3;
int state = 1;
boolean woordGeraden = false;
String[] woordenlijstNL;
boolean newwoord = true;
StartScherm startScherm;
SpeelScherm speelScherm;
EindScherm eindScherm;
SoundFile correct; 
SoundFile applaus; 
SoundFile fout; 
PImage ballon;
Ballon balling = new Ballon(50,200,20);

public void setup() {
  
  frameRate(1000);
  startScherm = new StartScherm(this);
  woordenlijstNL = loadStrings("woordenlijstNL.txt");
  ballon = loadImage("images/balloon.png");
  correct = new SoundFile(this, "sounds/applause-01.mp3");
  applaus = new SoundFile(this, "sounds/applause-02.mp3");
  fout = new SoundFile(this, "sounds/spongebob-boowomp.mp3");
}

public void draw() {
  background(0);
  switch(state) {
  case START:
    startScherm.tekenStartScherm();
    break;

  case SPEL:
    speelScherm.tekenSpeelveld();
    speelScherm.tekenWoorden();
    break;

  case EIND: 
    eindScherm.teken();
    eindScherm.ballon();
    break;
  }
}

public void keyPressed() {
  switch(state) {
  case START:
    startScherm.woord.voegLetterToe();
    break;

  case SPEL:
    speelScherm.typen();
    break;

  case EIND:
    break;
  }
}

public void mousePressed() {
  switch(state) {
  case START:
    startScherm.interactie();
    break;

  case SPEL:
    break;

  case EIND:
    eindScherm.interactie();
    break;
  }
}
class Ballon {
  int widthBallon;
  int heightBallon;
  int x;
  int y = height;

  Ballon(int widthb, int heightb, int x) {
    widthBallon = widthb;
    heightBallon = heightb;
    this.x = x;
    this.y = height;
  }

  public void move() {
    y--;
  }

  public void tekenBallon(){
  image(ballon, x, y, widthBallon, heightBallon);
  }

  public boolean checkOutOfBounds() {
    if (y < 0) {
      return true;
    } else {
    }
    return false;
  }
}

class EindScherm {
  Knop retry;
  PApplet papplet;
  Knop[] knoppen;
 ArrayList<Ballon> ballonnen;
  EindScherm(PApplet papplet) {
    this.retry = new Knop("Play again", width / 10, height / 10, width / 2 - width / 10, height - height / 8);
    this.knoppen = new Knop[1];
    ballonnen = new ArrayList<Ballon>();
    this.papplet = papplet;
    knoppen[0] = retry;
  }

  public void teken() {
    for (int i = 0; i < knoppen.length; i ++) {
      knoppen[i].tekenKnop();
    }
    if(woordGeraden){
    for(int i =0; i < ballonnen.size(); i++){
    ballonnen.get(i).tekenBallon();
    }
    }
    startScherm.woord.teken();
  }
  
  public void ballon(){
  if(PApplet.parseInt(random(100)) == 3){
  ballonnen.add(new Ballon(30 + PApplet.parseInt(random(10)), 40 + PApplet.parseInt(random(40)), PApplet.parseInt(random(width))));
  printArray(ballonnen);
    }
  for(int i =0; i < ballonnen.size(); i++){
  if(ballonnen.get(i).checkOutOfBounds()){
  ballonnen.remove(i);
  println(1);
  }
  ballonnen.get(i).move();
  }
  }
  

  public void interactie() {
    try {
      if (checkGeklikt() < knoppen.length) {
        gebruikKnop(checkGeklikt());
      }
    }
    catch(Exception EX) {
      println(EX);
    };
  }

  public int checkGeklikt() throws Exception {
    for (int i = 0; i < knoppen.length; i++)
      if (knoppen[i].isGeklikt()) {
        return i;
      }
    throw new Exception("KLIK OP DE KNOP");
  }

  public void gebruikKnop(int index) {
    switch(index) {
    case 0:
      state = START;
  startScherm = new StartScherm(papplet);
  woordGeraden = false;
      break;
    }
  }
}
class Knop {
  String tekst;
  int hoogte,breedte, x, y;

  Knop(String tekst, int breedte, int hoogte, int x, int y) {
    this.tekst = tekst;
    this.breedte = breedte;
    this.hoogte = hoogte;
    this.x = x;
    this.y = y;
  }

  public boolean isGeklikt() {
    if (mouseX > x && mouseX < x + breedte && mouseY > y && mouseY < y + hoogte) {
      return true;
    } 
    return false;
  }

  public void tekenKnop() {
    fill(255);
    rect(x, y, breedte,hoogte);
    fill(0);
    textAlign(CENTER, CENTER);
    textSize((breedte + hoogte) / 9);
    text(tekst, x + breedte / 2, y + hoogte / 2 );
  }
}


class SpeelScherm {
  Woord[] woorden;
  int[][] kubus;
  final int FOUT = 1;
  final int CORRECT = 2;
  final int VERKEERDEPLEK = 3;
  int woord;
  PApplet papplet;

  SpeelScherm(PApplet papplet) {
    woord = 0;
    woorden = new Woord[startScherm.woord.woordlength];
    this.papplet = papplet;
    kubus = new int[startScherm.woord.woordlength][startScherm.woord.woordlength];
    println(startScherm.woord.woordlength);
    for (int i = 0; i < startScherm.woord.woordlength; i++) {
      woorden[i] = new Woord();
      for (int j = 0; j < startScherm.woord.woordlength; j++) {
        kubus[i][j] = FOUT;
      }
    }
  }

  public void tekenSpeelveld() {
    for (int i = 0; i < startScherm.woord.woordlength; i++) {
      for (int j = 0; j < startScherm.woord.woordlength; j++) {
        switch (kubus[j][i]) {
        case FOUT:
          fill(255);
          break;

        case CORRECT:
          fill(0xff14FF00);
          break;

        case VERKEERDEPLEK:
          fill(0xffFFAC27);
          break;
        }
        rect(width / startScherm.woord.woordlength * i, height / startScherm.woord.woordlength * j, width / startScherm.woord.woordlength, height / startScherm.woord.woordlength);
      }
    }
  }

  public void tekenWoorden() {
    for (int i = 0; i < woord; i++) {
      for (int j = 0; j < woorden[0].woordlength; j++) {
        fill(0xffF50C0C);
        textSize( width / startScherm.woord.woordlength / 2);
        textAlign(CENTER, CENTER);
        text(str(woorden[i].woord[j]), width / startScherm.woord.woordlength * j + width / startScherm.woord.woordlength / 2, height / startScherm.woord.woordlength * i + height / startScherm.woord.woordlength / 3);
      }
    }

    for (int i = 0; i < woord + 1; i++) {
      for (int j = 0; j < woorden[woord].woordlength; j++) {
        fill(0xffF50C0C);
        textSize( width / startScherm.woord.woordlength / 2);
        textAlign(CENTER, CENTER);
        text(str(woorden[i].woord[j]), width / startScherm.woord.woordlength * j + width / startScherm.woord.woordlength / 2, height / startScherm.woord.woordlength * i + height / startScherm.woord.woordlength / 3);
      }
    }
  }

  public boolean getCorrect() {
    int correct = 0;
    for (int i = 0; i <  startScherm.woord.woordlength; i++) {
      if (woorden[woord].woord[i] == startScherm.woord.woord[i]) {
        correct ++;
      }
    }
    if (correct == startScherm.woord.woordlength) {
      return true;
    }
    printArray(woorden[woord].woord);
    printArray(startScherm.woord.woord);
    return false;
  }

  public void typen() {
    if (key == ENTER && woorden[woord].woordlength == startScherm.woord.woordlength && woord <= startScherm.woord.woordlength - 1) {
      if (getCorrect()) {
        eindScherm = new EindScherm(papplet);
        state = EIND;
        correct.play();
        applaus.play();
        woordGeraden = true;
      } else if (key == ENTER && woord == startScherm.woord.woordlength - 1) {
        eindScherm = new EindScherm(papplet);
        state = EIND;
        fout.play();
      }
      vergelijkWoord();
      woord ++;
    } else if (woorden[woord].woordlength < startScherm.woord.woordlength || key == BACKSPACE) {
      woorden[woord].voegLetterToe();
    }
  }

  public void vergelijkWoord() {
    for (int i = 0; i < woorden[woord].woordlength; i++) {
      if (woorden[woord].woord[i] == startScherm.woord.woord[i]) {
        kubus[woord][i] = CORRECT;
      } else { 
        int aantalGekleurd = 0;
        int aantalInWoord = 0;      
        int aantalCorrectInWoord = 0;
        int aantalCorrect = 0;
        for (int j = 0; j < woorden[woord].woordlength; j++) {
          if (woorden[woord].woord[i] == startScherm.woord.woord[j]) {
            aantalCorrectInWoord ++;
          }
        }
        println(aantalCorrectInWoord);
        for (int j = 0; j < woorden[woord].woordlength; j++) {
          if (woorden[woord].woord[i] == startScherm.woord.woord[j] && woorden[woord].woord[j] == startScherm.woord.woord[j]) {
            aantalCorrect += 1;
          }
        }
        aantalGekleurd += aantalCorrect;
        for (int j = 0; j < woorden[woord].woordlength; j++) {
          if (woorden[woord].woord[i] == startScherm.woord.woord[j]) {
            aantalInWoord ++;
          }
        }
        for (int j = 0; j < woorden[woord].woordlength; j++) {
          if ((kubus[woord][j] == VERKEERDEPLEK) && woorden[woord].woord[i] == woorden[woord].woord[j]) {
            aantalGekleurd ++;
          }
        }
        println(aantalGekleurd);
        for (int j = 0; j < woorden[woord].woordlength; j++) {
          if (woorden[woord].woord[i] == startScherm.woord.woord[j] && aantalGekleurd < aantalInWoord) {
            kubus[woord][i] = VERKEERDEPLEK;
          }
        }
      }
    }
  }
}

class StartScherm {
  Knop start;
  Woord woord;
  Knop randomNL;
  Knop randomENG;
  boolean encryptedTrue;
  Knop encrypted;
  Knop[] knoppen;
  int woordLength;
  PApplet papplet;

  StartScherm(PApplet papplet) {
    this.start = new Knop("Start", width / 10, height / 10, width / 4 - width / 5, height - height / 8);
    this.randomNL = new Knop("Random: NL", width / 10, height / 10, width - width / 4 - width / 5, height - height / 8);
    this.randomENG = new Knop("Random: EN", width / 10, height / 10, width - width / 5, height - height / 8);
    this.encrypted = new Knop("View Word", width / 10, height / 10, width / 2 - width / 5, height - height / 8);
    this.woord = new Woord();
    this.papplet = papplet;
    this.knoppen = new Knop[4];
    this.woordLength = 0;
    this.encryptedTrue = true;
    knoppen[0] = start;
    knoppen[1] = randomNL;
    knoppen[3] = randomENG;
    knoppen[2] = encrypted;
  }

  public void tekenStartScherm() {
    for (int i = 0; i < knoppen.length; i ++) {
      knoppen[i].tekenKnop();
    }
    if (encryptedTrue) {
      woord.tekenEncrypted();
    } else {
      woord.teken();
    }
  }

  public void interactie() {
    try {
      if (checkGeklikt() < knoppen.length) {
        gebruikKnop(checkGeklikt());
      }
    }
    catch(Exception EX) {
      println(EX);
    };
  }

  public int checkGeklikt() throws Exception {
    for (int i = 0; i < knoppen.length; i++)
      if (knoppen[i].isGeklikt()) {
        return i;
      }
    throw new Exception("KLIK OP DE KNOP");
  }

  public void gebruikKnop(int index) {
    switch(index) {
    case 0:
      if (woord.woordlength > 0) {
        state = SPEL;
        speelScherm = new SpeelScherm(papplet);
      }
      break;
    case 1:
      if (woord.woordlength == 0) {
        woord.woord = expand(woord.woord, woord.woordlength + 1);
        woord.woordlength++;
      }
      int randomNL = PApplet.parseInt(random(woordenlijstNL.length - 1));
         char[] placeholder = new char[woordenlijstNL[randomNL].length()];
      for (int i = 0; i < woordenlijstNL[randomNL].length(); i++) {
        placeholder[i] = woordenlijstNL[randomNL].charAt(i);
      }
      woord.woord = placeholder;
      woord.woordlength = woord.woord.length;
      break;
    case 2:
      if (encryptedTrue) {
        encryptedTrue = false;
      } else {
        encryptedTrue = true;
      }
      break;
      //case 3:
      //  if (woord.woordlength == 0) {
      //    woord.woord = expand(woord.woord, woord.woordlength + 1);
      //    woord.woordlength++;
      //  }
      //  int randomENG = int(random(woordenBankENG.length - 1));
      //  woord.woord = woordenBankENG[randomENG];
      //  woord.woordlength = woordenBankENG[randomENG].length;
      //  state = SPEL;
      //  speelScherm = new SpeelScherm();
      //  break;
    }
  }
}
class Woord {
  char woord[];
  int woordlength;
  Woord() {
    this.woord = new char[1];
    this.woordlength = 0;
  }

  public void voegLetterToe() {
    if ( key == BACKSPACE && woordlength > 0) {
    woord = shorten(woord);
    woordlength --;
    }else if(key != ENTER && key != CODED && woordlength < 23 && key != BACKSPACE){
      woord = expand(woord, woordlength + 1);
      woord[woordlength] = key;
      woordlength ++;
    }
  }

  public void teken() {
    if (woordlength != 0) {
      String tekst = "";
      for (int i = 0; i < woord.length; i ++) { 
        tekst += woord[i];
      }
      textSize((width + height) / 120 + ((width + height) / ((woord.length + 1) * 1.5f) / 2 )); 
      fill(255);
      text(tekst, width / 2, height / 2);
    }
  }
   public void tekenEncrypted() {
    if (woordlength != 0) {
      String tekst = "";
      for (int i = 0; i < woord.length; i ++) { 
        tekst += "*";
      }
      textSize((width + height) / 120 + ((width + height) / ((woord.length + 1) * 1.5f) / 2 )); 
      fill(255);
      text(tekst, width / 2, height / 2);
    }
  }
  
}


//char[][] woordenBankNL = {
//  {'l', 'o', 'p', 'e', 'n', }, 
//  {'s', 'l', 'o', 'p', 'e', 'n'}, 
//  {'t', 'a', 'n', 'd', 'e', 'n'}, 
//  {'m', 'a', 'n', 'd', 'e', 'n'}, 
//  {'s', 'a', 'l', 'a', 'd', 'e'}, 
//  {'g', 'a', 'r', 'a', 'g', 'e'}, 
//  {'v', 'a', 'l', 'k', 'u', 'i', 'l'}, 
//  {'b', 'e', 'r', 'e', 'n', 'k', 'l', 'e', 'm'}, 
//  {'p', 'i', 'z', 'z', 'a', 's', 'c', 'h', 'e', 'p'}, 
//  {'w', 'a', 'l', 'n', 'o', 'o', 't'}, 
//  {'e', 't', 'e', 'n'}, 
//  {'k', 'u', 'i', 'l'}, 
//  {'b', 'i', 'b', 'l', 'i', 'o', 't', 'h', 'e', 'e', 'k'}, 
//  {'c', 'a', 'v', 'i', 'a'}, 
//  {'b', 'r', 'o', 'o', 'd'}, 
//  {'k', 'o', 'f', 'f', 'i', 'e'}, 
//  {'c', 'h', 'o', 'c', 'o', 'l', 'a'}, 
//  {'s', 't', 'e', 'e', 'n'}, 
//  {'s', 't', 'o', 'e', 'l'}, 
//  {'f', 'i', 'e', 't', 's'}, 
//  {'p', 'i', 'z', 'z', 'a'}, 
//  {'p', 'i', 'n', 'd', 'a'}, 
//  {'s', 't', 'e', 'e', 'g'}, 
//  {'s', 't', 'e', 'e', 'l'}, 
//  {'s', 't', 'e', 'e', 'k'}, 
//  {'s', 't', 'i', 'j', 'f'}, 
//  {'s', 'c', 'h', 'a', 'a', 'r'}, 
//  {'s', 't', 'r', 'a', 'f'}, 
//  {'t', 'o', 'e', 't', 's'}, 
//  {'t', 'a', 's', 'e', 'r'}, 
//  {'s', 'u', 'p', 'e', 'r'}, 
//  {'s', 't', 'e', 'r', 'f'}, 
//  {'g', 'l', 'a', 'n', 's'}, 
//  {'b', 'e', 'z', 'e', 'm'}, 
//  {'m', 'e', 't', 'e', 'n'}, 
//  {'l', 'e', 'z', 'e', 'n'}, 
//  {'m', 'a', 'r', 'i', 'o'}, 
//  {'w', 'o', 'd', 'k', 'a'}, 
//  {'b', 'e', 'k', 'e', 'r'}, 
//  {'s', 'm', 'a', 's', 'h'}, 
//  {'i', 'j', 'z', 'e', 'r'}, 
//  {'b', 'a', 'k', 'e', 'n'}
//};

//char[][] woordenBankENG = {{'s','t','e','a','l'},
//{'s','t','o','n','e'},
//{'b','e','a','c','h'},
//{'p','e','a','c','h'},
//{'s','h','i','n','e'},
//{'b','l','o','o','d'},
//{'s','t','o','o','p'},};
  public void settings() {  size(1600, 900); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "LINGO" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
