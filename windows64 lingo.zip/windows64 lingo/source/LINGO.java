import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class LINGO extends PApplet {

final int START = 1;
final int SPEL = 2;
final int EIND = 3;
int state = 1;
boolean newwoord = true;
StartScherm startScherm;
SpeelScherm speelScherm;
EindScherm eindScherm;
public void setup() {
  
  frameRate(1000);
  startScherm = new StartScherm();
  surface.setResizable(true);
}

public void draw() {
  background(0);

  switch(state) {
  case START:
    startScherm.tekenStartScherm();
    break;

  case SPEL:
    speelScherm.tekenSpeelveld();
    speelScherm.tekenWoorden();
    break;

  case EIND:
  eindScherm.teken();
    break;
  }
}

public void keyPressed() {
  switch(state) {
  case START:
    startScherm.woord.voegLetterToe();
    break;

  case SPEL:
    speelScherm.typen();
    break;

  case EIND:
    break;
  }
}

public void mousePressed() {
  switch(state) {
  case START:
    startScherm.interactie();
    break;

  case SPEL:
    break;

  case EIND:
  eindScherm.interactie();
    break;
  }
}
class EindScherm {
  Knop retry;
  Knop[] knoppen;
  EindScherm() {
    this.retry = new Knop("Play again", width / 10, height / 10, width / 2 - width / 10, height - height / 8);
    this.knoppen = new Knop[1];
    knoppen[0] = retry;
  }

  public void teken() {
    for (int i = 0; i < knoppen.length; i ++) {
      knoppen[i].tekenKnop();
    }
    startScherm.woord.teken();
  }

  public void interactie() {
    try {
      if (checkGeklikt() < knoppen.length) {
        gebruikKnop(checkGeklikt());
      }
    }
    catch(Exception EX) {
      println(EX);
    };
  }

  public int checkGeklikt() throws Exception {
    for (int i = 0; i < knoppen.length; i++)
      if (knoppen[i].isGeklikt()) {
        return i;
      }
    throw new Exception("KLIK OP DE KNOP");
  }

  public void gebruikKnop(int index) {
    switch(index) {
    case 0:
      state = START;
  startScherm = new StartScherm();
      break;
    }
  }
}
class Knop {
  String tekst;
  int hoogte,breedte, x, y;

  Knop(String tekst, int breedte, int hoogte, int x, int y) {
    this.tekst = tekst;
    this.breedte = breedte;
    this.hoogte = hoogte;
    this.x = x;
    this.y = y;
  }

  public boolean isGeklikt() {
    if (mouseX > x && mouseX < x + breedte && mouseY > y && mouseY < y + hoogte) {
      return true;
    } 
    return false;
  }

  public void tekenKnop() {
    fill(255);
    rect(x, y, breedte,hoogte);
    fill(0);
    textAlign(CENTER, CENTER);
    textSize((breedte + hoogte) / 9);
    text(tekst, x + breedte / 2, y + hoogte / 2 );
  }
}
class SpeelScherm {
  Woord[] woorden;
  int[][] kubus;
  final int FOUT = 1;
  final int CORRECT = 2;
  final int VERKEERDEPLEK = 3;
  int woord;

  SpeelScherm() {
    woord = 0;
    woorden = new Woord[startScherm.woord.woordlength];
    kubus = new int[startScherm.woord.woordlength][startScherm.woord.woordlength];
    println(startScherm.woord.woordlength);
    for (int i = 0; i < startScherm.woord.woordlength; i++) {
      woorden[i] = new Woord();
      for (int j = 0; j < startScherm.woord.woordlength; j++) {
        kubus[i][j] = FOUT;
      }
    }
  }

  public void tekenSpeelveld() {
    for (int i = 0; i < startScherm.woord.woordlength; i++) {
      for (int j = 0; j < startScherm.woord.woordlength; j++) {
        switch (kubus[j][i]) {
        case FOUT:
          fill(255);
          break;

        case CORRECT:
          fill(0xff14FF00);
          break;

        case VERKEERDEPLEK:
          fill(0xffFFAC27);
          break;
        }
        rect(width / startScherm.woord.woordlength * i, height / startScherm.woord.woordlength * j, width / startScherm.woord.woordlength, height / startScherm.woord.woordlength);
      }
    }
  }

  public void tekenWoorden() {
    for (int i = 0; i < woord; i++) {
      for (int j = 0; j < woorden[0].woordlength; j++) {
        fill(0xffF50C0C);
        textSize( width / startScherm.woord.woordlength / 2);
        textAlign(CENTER, CENTER);
        text(str(woorden[i].woord[j]), width / startScherm.woord.woordlength * j + width / startScherm.woord.woordlength / 2, height / startScherm.woord.woordlength * i + height / startScherm.woord.woordlength / 4);
      }
    }

    for (int i = 0; i < woord + 1; i++) {
      for (int j = 0; j < woorden[woord].woordlength; j++) {
        fill(0xffF50C0C);
        textSize( width / startScherm.woord.woordlength / 2);
        textAlign(CENTER, CENTER);
        text(str(woorden[i].woord[j]), width / startScherm.woord.woordlength * j + width / startScherm.woord.woordlength / 2, height / startScherm.woord.woordlength * i + height / startScherm.woord.woordlength / 4);
      }
    }
  }

  public boolean getCorrect() {
    int correct = 0;
    for (int i = 0; i <  startScherm.woord.woordlength; i++) {
      if (woorden[woord].woord[i] == startScherm.woord.woord[i]) {
        correct ++;
      }
    }
    if (correct == startScherm.woord.woordlength) {
      return true;
    }
    printArray(woorden[woord].woord);
    printArray(startScherm.woord.woord);
    return false;
  }

  public void typen() {
    if (key == ENTER && woorden[woord].woordlength == startScherm.woord.woordlength && woord <= startScherm.woord.woordlength - 1) {
      if ((key == ENTER && woord == startScherm.woord.woordlength - 1) || getCorrect()) {
        eindScherm = new EindScherm();
        state = EIND;
      }
      vergelijkWoord();
      woord ++;
    } else if (woorden[woord].woordlength < startScherm.woord.woordlength || key == BACKSPACE) {
      woorden[woord].voegLetterToe();
    }
  }

  public void vergelijkWoord() {
    for (int i = 0; i < woorden[woord].woordlength; i++) {
      if (woorden[woord].woord[i] == startScherm.woord.woord[i]) {
        kubus[woord][i] = CORRECT;
      } else { 
        for (int j = 0; j < woorden[woord].woordlength; j++) {
          if (woorden[woord].woord[i] == startScherm.woord.woord[j]) {
            kubus[woord][i] = VERKEERDEPLEK;
          }
        }
      }
    }
  }
}
char[][] woordenBank = {
  {'l', 'o', 'p', 'e', 'n', }, 
  {'s', 'l', 'o', 'p', 'e', 'n'}, 
  {'t', 'a', 'n', 'd', 'e', 'n'}, 
  {'m', 'a', 'n', 'd', 'e', 'n'}, 
  {'s', 'a', 'l', 'a', 'd', 'e'}, 
  {'g', 'a', 'r', 'a', 'g', 'e'}, 
  {'v', 'a', 'l', 'k', 'u', 'i', 'l'}, 
  {'b', 'e', 'r', 'e', 'n', 'k', 'l', 'e', 'm'}, 
  {'p', 'i', 'z', 'z', 'a', 's', 'c', 'h', 'e', 'p'}, 
  {'w', 'a', 'l', 'n', 'o', 'o', 't'}, 
  {'e', 't', 'e', 'n'}, 
  {'n', 'e', 'e'}, 
  {'k', 'u', 'i', 'l'}, 
  {'b', 'i', 'b', 'l', 'i', 'o', 't', 'h', 'e', 'e', 'k'}, 
  {'c', 'a', 'v', 'i', 'a'}, 
  {'b', 'r', 'o', 'o', 'd'}, 
  {'k', 'o', 'f', 'f', 'i', 'e'}, 
  {'c', 'h', 'o', 'c', 'o', 'l', 'a'}, 
  {'s', 't', 'e', 'e', 'n'}, 
  {'s', 't', 'o', 'e', 'l'}, 
  {'f', 'i', 'e', 't', 's'}, 
  {'p', 'i', 'z', 'z', 'a'}, 
  {'p', 'i', 'n', 'd', 'a'}, 
  {'s', 't', 'e', 'e', 'g'}, 
  {'s', 't', 'e', 'e', 'l'}, 
  {'s', 't', 'e', 'e', 'k'}, 
  {'s', 't', 'i', 'j', 'f'}, 
  {'s', 'c', 'h', 'a', 'a', 'r'}, 
  {'s', 't', 'r', 'a', 'f'}, 
  {'t', 'o', 'e', 't', 's'}, 
  {'t', 'a', 's', 'e', 'r'}, 
  {'s', 'u', 'p', 'e', 'r'}, 
  {'s', 't', 'e', 'r', 'f'}, 
  {'g', 'l', 'a', 'n', 's'}, 
  {'b', 'e', 'z', 'e', 'm'}, 
  {'m', 'e', 't', 'e', 'n'}, 
  {'l', 'e', 'z', 'e', 'n'}, 
  {'m', 'a', 'r', 'i', 'o'}, 
  {'w', 'o', 'd', 'k', 'a'}, 
  {'b', 'e', 'k', 'e', 'r'}, 
  {'s', 'm', 'a', 's', 'h'}, 
  {'i', 'j', 'z', 'e', 'r'}, 
  {'b', 'a', 'k', 'e', 'n'}
};

class StartScherm {
  Knop start;
  Woord woord;
  Knop random;
  Knop[] knoppen;
  int woordLength;

  StartScherm() {
    this.start = new Knop("Start", width / 10, height / 10, width / 4, height - height / 8);
    this.random = new Knop("Random", width / 10, height / 10, width - width / 4 - width / 10, height - height / 8);
    this.woord = new Woord();
    this.knoppen = new Knop[2];
    this.woordLength = 0;
    knoppen[0] = start;
    knoppen[1] = random;
  }

  public void tekenStartScherm() {
    for (int i = 0; i < knoppen.length; i ++) {
      knoppen[i].tekenKnop();
    }
    woord.teken();
  }

  public void interactie() {
    try {
      if (checkGeklikt() < knoppen.length) {
        gebruikKnop(checkGeklikt());
      }
    }
    catch(Exception EX) {
      println(EX);
    };
  }

  public int checkGeklikt() throws Exception {
    for (int i = 0; i < knoppen.length; i++)
      if (knoppen[i].isGeklikt()) {
        return i;
      }
    throw new Exception("KLIK OP DE KNOP");
  }

  public void gebruikKnop(int index) {
    switch(index) {
    case 0:
      if (woord.woordlength > 0) {
        state = SPEL;
        speelScherm = new SpeelScherm();
      }
      break;
    case 1:

      if (woord.woordlength == 0) {
        woord.woord = expand(woord.woord, woord.woordlength + 1);
        woord.woordlength++;
      }
      int random = PApplet.parseInt(random(woordenBank.length - 1));
      woord.woord = woordenBank[random];
      woord.woordlength = woordenBank[random].length;
      break;
    }
  }
}
class Woord {
  char woord[];
  int woordlength;
  Woord() {
    this.woord = new char[1];
    this.woordlength = 0;
  }

  public void voegLetterToe() {
    if ( key == BACKSPACE && woordlength > 0) {
    woord = shorten(woord);
    woordlength --;
    }else if(key != ENTER && key != CODED && woordlength < 23 && key != BACKSPACE){
      woord = expand(woord, woordlength + 1);
      woord[woordlength] = key;
      woordlength ++;
    }
  }

  public void teken() {
    if (woordlength != 0) {
      String tekst = "";
      for (int i = 0; i < woord.length; i ++) { 
        tekst += woord[i];
      }
      textSize((width + height) / 120 + ((width + height) / ((woord.length + 1) * 1.5f) / 2 )); 
      fill(255);
      text(tekst, width / 2, height / 2);
    }
  }
}
  public void settings() {  size(1600, 900); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "LINGO" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
